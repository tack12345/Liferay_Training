package cts.employee.management.action;

/* Imports required packages*/
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import cts.employee.management.constants.EmployeeManagementPortletKeys;
import cts.employee.service.EmployeeLocalService;

@Component(
		property = {
				"javax.portlet.name=" + EmployeeManagementPortletKeys.EMPLOYEEMANAGEMENT,
				"mvc.command.name=deleteAction"
		},
		service=MVCActionCommand.class
		)
public class DeleteEmployee extends BaseMVCActionCommand {
	
	/*Injects the required services */
	@Reference
	EmployeeLocalService employeeLocalService;
	
	/*Overrides the doprocessaction method from BaseMVCActionCommand*/
	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		
		/* Retrieves employeeId from the action request parameters  */
		long employeeId = ParamUtil.getLong(actionRequest, "employeeId");
		
		/* Checks if the generated employeeId is not null  */
		if(Validator.isNotNull(employeeId)) {
			
			/* Deletes the employee from the database using the employeeLocalService  */
			employeeLocalService.deleteEmployee(employeeId);
			
			/* Adds success message to the session */
			SessionMessages.add(actionRequest, "delete");
		}
	}

}
