package cts.employee.management.action;

/* Imports required packages*/
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import cts.employee.management.constants.EmployeeManagementPortletKeys;
import cts.employee.model.Employee;
import cts.employee.service.EmployeeLocalService;

@Component(
		property= {
				"javax.portlet.name=" + EmployeeManagementPortletKeys.EMPLOYEEMANAGEMENT,
				"mvc.command.name=updateAction"
		},
		service = MVCActionCommand.class
		)
public class UpdateEmployee extends BaseMVCActionCommand {
	
	private final Log log = LogFactoryUtil.getLog(UpdateEmployee.class.getName());
	
	/*Injects the required services */
	@Reference
	EmployeeLocalService employeeLocalService;
	
	
	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		
		/* Retrieves employeeId from the action request parameters  */
		long employeeId = ParamUtil.getLong(actionRequest, "employeeId");
		log.info("Employee Id is -------"+employeeId);
		
		/* Retrieves the cmd parameter from the action request parameters  */
		String cmd=ParamUtil.getString(actionRequest, "cmd");
		
		/* Retrieves the employee job and department from the action request parameters  */
		String employeeJob=ParamUtil.getString(actionRequest, "employeeJob");
		log.info("Employee Job is -------"+employeeJob);
		String employeeDepartment=ParamUtil.getString(actionRequest, "employeeDepartment");
		log.info("Employee Department is -------"+employeeDepartment);
		
		/* Checks if the generated employeeId is not null */
		if(Validator.isNotNull(employeeId)) {
			if(cmd.contains("edit")) {
				
				/* Sets the employeeId attribute in the action request to be used in the render phase  */
				actionRequest.setAttribute("employeeId", employeeId);
				
				/* Sets the mvcPath parameter in the render parameters to specify the JSP to be rendered*/
				actionResponse.getRenderParameters().setValue("mvcPath", "/updateEmployee.jsp");
			}
			else {
				 log.info("Coming inside else condition");
				 
				 /* Retrieves the existing employee from the database using the employeeLocalService*/
				 Employee employee = employeeLocalService.getEmployee(employeeId);
				 
				 /* Updates the employee's job and department  */
				 employee.setEmployeeJob(employeeJob);
				 employee.setEmployeeDepartment(employeeDepartment);
				 
				 /* Update the employee in the database using the employeeLocalService  */
				 employeeLocalService.updateEmployee(employee);
				 
				 /* Adds success messageto the session */
				 SessionMessages.add(actionRequest, "update");
			}
			
		}
		
		
	}

}
