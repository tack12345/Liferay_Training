package cts.employee.management.constants;

/**
 * @author 2264878
 */
public class EmployeeManagementPortletKeys {

	public static final String EMPLOYEEMANAGEMENT =
		"cts_employee_management_EmployeeManagementPortlet";

}