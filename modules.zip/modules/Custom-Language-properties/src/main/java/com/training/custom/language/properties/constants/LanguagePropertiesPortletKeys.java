package com.training.custom.language.properties.constants;

/**
 * @author 2264878
 */
public class LanguagePropertiesPortletKeys {

	public static final String LANGUAGEPROPERTIES =
		"com_training_custom_language_properties_LanguagePropertiesPortlet";

}