package com.training.custom.language.properties.portlet;

import com.training.custom.language.properties.constants.LanguagePropertiesPortletKeys;

import java.util.Enumeration;
import java.util.ResourceBundle;

import com.liferay.portal.kernel.language.UTF8Control;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;

import javax.portlet.Portlet;

import org.osgi.service.component.annotations.Component;

@Component(
	property = {
		
		"language.id=en_US"
	},
	service = ResourceBundle.class
)

public class CustomLanguage extends ResourceBundle {
	
	
	
    private final ResourceBundle resourceBundle=ResourceBundle.getBundle("content.Language", UTF8Control.INSTANCE);
	@Override
	protected Object handleGetObject(String key) {
		
		return resourceBundle.getObject(key);
	}

	@Override
	public Enumeration<String> getKeys() {
		
		return resourceBundle.getKeys();
	}

}
