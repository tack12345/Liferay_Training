package com.training.listener.constants;

/**
 * @author 2264878
 */
public class CustomListenerPortletKeys {

	public static final String CUSTOMLISTENER =
		"com_training_listener_CustomListenerPortlet";

}