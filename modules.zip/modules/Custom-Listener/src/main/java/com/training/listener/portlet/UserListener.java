package com.training.listener.portlet;

import com.liferay.portal.kernel.exception.ModelListenerException;
import com.liferay.portal.kernel.model.BaseModelListener;
import com.liferay.portal.kernel.model.ModelListener;
import com.liferay.portal.kernel.model.User;
import org.osgi.service.component.annotations.Component;

@Component(
	immediate = true,
	service = ModelListener.class
)
public class UserListener extends BaseModelListener<User> {
	@Override
	public void onBeforeCreate(User model) throws ModelListenerException {
		
		
		System.out.println("User Details before event" + model);
		model.setJobTitle("CTS-EMPLOYEE");
		super.onBeforeCreate(model);
	}
	
	@Override
	public void onAfterCreate(User model) throws ModelListenerException {
		System.out.println("User Details after event" + model);
		super.onAfterCreate(model);
	}

}
