package com.training.custom.user.service.wrapper.constants;

/**
 * @author 2264878
 */
public class CustomUserServiceWrapperPortletKeys {

	public static final String CUSTOMUSERSERVICEWRAPPER =
		"com_training_custom_user_service_wrapper_CustomUserServiceWrapperPortlet";

}