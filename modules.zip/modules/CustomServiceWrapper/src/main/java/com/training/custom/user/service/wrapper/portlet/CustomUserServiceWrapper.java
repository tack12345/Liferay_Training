package com.training.custom.user.service.wrapper.portlet;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.service.ServiceWrapper;
import com.liferay.portal.kernel.service.UserLocalServiceWrapper;

import java.util.Map;

import javax.portlet.Portlet;

import org.osgi.service.component.annotations.Component;

@Component(
	
	
	service = ServiceWrapper.class
	)


public class CustomUserServiceWrapper extends UserLocalServiceWrapper {

	@Override
	public int getUsersCount() {
		System.out.println("Total number of user counts");
		return super.getUsersCount();
	}

	@Override
	public int authenticateByEmailAddress(long companyId, String emailAddress, String password,
			Map<String, String[]> headerMap, Map<String, String[]> parameterMap, Map<String, Object> resultsMap)
			throws PortalException {
		System.out.println("Your email address is : " + emailAddress);
		return super.authenticateByEmailAddress(companyId, emailAddress, password, headerMap, parameterMap, resultsMap);
	}
	
	

}
