package com.formnative.constants;

/**
 * @author 2264878
 */
public class FormNativePortletKeys {

	public static final String FORMNATIVE =
		"com_formnative_FormNativePortlet";

}