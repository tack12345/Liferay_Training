package com.formnative.portlet;

import com.formnative.constants.FormNativePortletKeys;
import com.liferay.adaptive.media.exception.AMRuntimeException.IOException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;

import org.osgi.service.component.annotations.Component;

/**
 * @author 2264878
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=FormNative",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + FormNativePortletKeys.FORMNATIVE,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class FormNativePortlet extends MVCPortlet {
	@ProcessAction(name = "formMvc")
    public void testform(ActionRequest request, ActionResponse response) throws IOException, PortletException {
        String name = ParamUtil.getString(request, "name");
        String email = ParamUtil.getString(request, "email");
        String phone = ParamUtil.getString(request, "phone");
        

 

        System.out.println("Name :" + name);
        System.out.println("Email :" + email);
        System.out.println("Phone :" + phone);
        

 

        request.setAttribute("name", name);
        request.setAttribute("email", email);
        request.setAttribute("phone", phone);
        

 

        response.setRenderParameter("mvcPath", "/Finalview.jsp");

 

    }

}