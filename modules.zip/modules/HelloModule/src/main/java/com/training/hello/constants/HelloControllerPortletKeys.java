package com.training.hello.constants;

/**
 * @author 2264878
 */
public class HelloControllerPortletKeys {

	public static final String HELLOCONTROLLER =
		"com_training_hello_HelloControllerPortlet";

}