package com.mvcaction.constants;

/**
 * @author 2264878
 */
public class MVCActionPortletKeys {

	public static final String MVCACTION =
		"com_mvcaction_MVCActionPortlet";

}