package com.mvcaction.controller;

import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.mvcaction.constants.MVCActionPortletKeys;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;

@Component(immediate = true, property = {
		"javax.portlet.name=" + MVCActionPortletKeys.MVCACTION,
        "mvc.command.name=testform"
}, 
service = MVCActionCommand.class)

 public class MVCActionPortletController extends BaseMVCActionCommand{
    @Override
    protected void doProcessAction(ActionRequest request, ActionResponse response) throws Exception{
        String firstName = ParamUtil.getString(request, "firstName");
        String lastName = ParamUtil.getString(request, "lastName");
        String mnumber = ParamUtil.getString(request, "mnumber");
        
        request.setAttribute("firstName", firstName);
        request.setAttribute("lastName", lastName);
        request.setAttribute("mnumber", mnumber);
        response.setRenderParameter("mvcPath", "/display.jsp");

 

    }
}
