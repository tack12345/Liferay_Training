package com.mvcrender.constants;

/**
 * @author 2264878
 */
public class MVCRenderPortletKeys {

	public static final String MVCRENDER =
		"com_mvcrender_MVCRenderPortlet";

}