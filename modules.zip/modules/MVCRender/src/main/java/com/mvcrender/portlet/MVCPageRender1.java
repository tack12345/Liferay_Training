package com.mvcrender.portlet;

import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.mvcrender.constants.MVCRenderPortletKeys;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

@Component (immediate = true, property = {"javax.portlet.name=" + MVCRenderPortletKeys.MVCRENDER, 
		"mvc.command.name=view_page"
},service = MVCRenderCommand.class)
public class MVCPageRender1 implements MVCRenderCommand{

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		System.out.println("This is MVC Render Page 1");
		return "/mvcrender1.jsp";
	}
	

}
