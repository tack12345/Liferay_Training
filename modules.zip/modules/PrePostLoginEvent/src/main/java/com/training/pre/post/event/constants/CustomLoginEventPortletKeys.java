package com.training.pre.post.event.constants;

/**
 * @author 2264878
 */
public class CustomLoginEventPortletKeys {

	public static final String CUSTOMLOGINEVENT =
		"com_training_pre_post_event_CustomLoginEventPortlet";

}