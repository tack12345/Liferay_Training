package com.test.constants;

/**
 * @author 2264878
 */
public class TestPortletKeys {

	public static final String TEST =
		"com_test_TestPortlet";

}