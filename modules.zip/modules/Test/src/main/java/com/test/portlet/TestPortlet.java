package com.test.portlet;

import com.test.constants.TestPortletKeys;
import com.liferay.adaptive.media.exception.AMRuntimeException.IOException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.Portlet;

import org.osgi.service.component.annotations.Component;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

/**
 * @author 2264878
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"com.liferay.portlet.requires-namespaced-parameters=false",
		"javax.portlet.display-name=Test",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + TestPortletKeys.TEST,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class TestPortlet extends MVCPortlet {
	
	@ProcessAction(name = "processAction")
	public void processAction(ActionRequest actionRequest, ActionResponse actionResponse)
			throws java.io.IOException, PortletException {
		String fname = ParamUtil.getString(actionRequest, "fname");
        String lname = ParamUtil.getString(actionRequest, "lname");
        String email = ParamUtil.getString(actionRequest, "email");
        String mnumber = ParamUtil.getString(actionRequest, "mnumber");

        
        System.out.println(fname +" "+lname+" "+email+" "+mnumber);	
        }

	
	
}


