package com.test.portlet.render;

import com.test.constants.TestPortletKeys;
import com.liferay.adaptive.media.exception.AMRuntimeException.IOException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
//import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.Portlet;

import org.osgi.service.component.annotations.Component;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
//import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

/**
 * @author 2264878
 */
@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + TestPortletKeys.TEST,
		"mvc.command.name="
	},
	service = MVCRenderCommand.class
)
public class MVCRender implements MVCRenderCommand {
	
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		// TODO Auto-generated method stub
		return "/view.jsp";
	}
	
	
}


