package cts.employee.management.action;

/* Imports required packages*/
import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import cts.employee.management.constants.EmployeeManagementPortletKeys;
import cts.employee.model.Employee;
import cts.employee.service.EmployeeLocalService;

@Component(
		property = {
				"javax.portlet.name=" + EmployeeManagementPortletKeys.EMPLOYEEMANAGEMENT,
				"mvc.command.name=addEmployee"
		},
		service=MVCActionCommand.class
		
		)
public class AddEmployee extends BaseMVCActionCommand {
	/*Injects the required services */
	@Reference
	EmployeeLocalService employeeLocalService;
	
	@Reference
	CounterLocalService counterLocalService;
	
	private final Log log=LogFactoryUtil.getLog(AddEmployee.class.getName());
	
	/*Overrides the doprocessaction method from BaseMVCActionCommand*/
	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		
		try {
			/* Generates a new employeeId using the counter service  */
			long employeeId=counterLocalService.increment(Employee.class.getName());
			
			/* Checks if the generated employeeId is not null  */
			if(Validator.isNotNull(employeeId)){
				
			/* Retrieves employee details from the action request parameters  */
		    String fname = ParamUtil.getString(actionRequest, "employeeFirstName");
		    String lname = ParamUtil.getString(actionRequest, "employeeLastName");
		    Date dob = ParamUtil.getDate(actionRequest, "employeeDob", new SimpleDateFormat("yyyy-MM-dd"));
		    String job = ParamUtil.getString(actionRequest, "employeeJob");
		    String dept = ParamUtil.getString(actionRequest, "employeeDepartment");
		    
		    /* Creates a new Employee instance and sets its properties */
			Employee employee = employeeLocalService.createEmployee(employeeId);
			employee.setEmployeeFirstName(fname);
			employee.setEmployeeLastName(lname);
			employee.setEmployeeDob(dob);
			employee.setEmployeeJob(job);
			employee.setEmployeeDepartment(dept);
			employee.setEmployeeId(employeeId);
			
			/* Adds the employee to the database  */
			employeeLocalService.addEmployee(employee);
			
			/* Adds success message to the session */
			SessionMessages.add(actionRequest, "success");
			
			/* Logs success message  */
			log.info("Hurray !! ----<<<<<<<<Your data has been added sucessfully---->>>>>>>>");
			}
			
		}catch(Exception e) {
			/* Adds error message to the session  */
			SessionMessages.add(actionRequest, "error");
			
			/* Logs the exception  */
			log.error("While adding data you are getting exception", e.fillInStackTrace());
			
		}
			}
}
