package cts.employee.management.action;

/* Imports required packages*/
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import cts.employee.management.constants.EmployeeManagementPortletKeys;
import cts.employee.model.Employee;
import cts.employee.service.EmployeeLocalService;

@Component(
		property= {
				"javax.portlet.name=" + EmployeeManagementPortletKeys.EMPLOYEEMANAGEMENT,
				"mvc.command.name=ReadAction"
		},
		service = MVCActionCommand.class
		)

public class ReadEmployee extends BaseMVCActionCommand {

	
	private final Log log = LogFactoryUtil.getLog(UpdateEmployee.class.getName());
	
	/*Injects the required services */
	@Reference
	EmployeeLocalService employeeLocalService;
	
	
	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		
		/* Retrieves employeeId from the action request parameters  */
		long employeeId = ParamUtil.getLong(actionRequest, "employeeId");
		
		/* Retrieves the cmd parameter from the action request parameters  */
		String cmd=ParamUtil.getString(actionRequest, "cmd");
		
		/* Checks if the generated employeeId is not null  */
		if(Validator.isNotNull(employeeId)) {
			if(cmd.contains("edit")) {
				
				/* Sets the employeeId attributein the action request to be used in the render phase  */
				actionRequest.setAttribute("employeeId", employeeId);
				
				/* Sets the mvcPath parameterin the render parameters to specify the JSP to be rendered  */
				actionResponse.getRenderParameters().setValue("mvcPath", "/viewrender.jsp");
			}
	}
	}
}
