package cts.employee.management.portlet;

import cts.employee.management.constants.EmployeeManagementPortletKeys;
import cts.employee.model.Employee;
import cts.employee.service.EmployeeLocalService;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;

import java.io.IOException;
import java.util.List;

import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=EmployeeManagement",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + EmployeeManagementPortletKeys.EMPLOYEEMANAGEMENT,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class EmployeeManagementPortlet extends MVCPortlet {
	
	private final Log log=LogFactoryUtil.getLog(EmployeeManagementPortlet.class.getName());
	
	@Reference
	EmployeeLocalService employeeLocalService;
	
	
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
		
		/* Retrieves the list of employees from the employeeLocalService*/
		List<Employee> employeeList  = employeeLocalService.getEmployees(-1, -1);
		
		/* Logs the employee count */
		log.info("Employee count " + employeeLocalService.getEmployeesCount());
		
		/* Sets the employeeList attribute in the render request to be used in the view*/
		renderRequest.setAttribute("employeeList",employeeList );
		
		//Calls the parent render method to be continue with the rendering
		super.render(renderRequest, renderResponse);
	}
}