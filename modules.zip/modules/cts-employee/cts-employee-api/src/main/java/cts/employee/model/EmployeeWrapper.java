/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package cts.employee.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Employee}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Employee
 * @generated
 */
public class EmployeeWrapper
	extends BaseModelWrapper<Employee>
	implements Employee, ModelWrapper<Employee> {

	public EmployeeWrapper(Employee employee) {
		super(employee);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("employeeId", getEmployeeId());
		attributes.put("employeeFirstName", getEmployeeFirstName());
		attributes.put("employeeLastName", getEmployeeLastName());
		attributes.put("employeeDob", getEmployeeDob());
		attributes.put("employeeJob", getEmployeeJob());
		attributes.put("employeeDepartment", getEmployeeDepartment());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long employeeId = (Long)attributes.get("employeeId");

		if (employeeId != null) {
			setEmployeeId(employeeId);
		}

		String employeeFirstName = (String)attributes.get("employeeFirstName");

		if (employeeFirstName != null) {
			setEmployeeFirstName(employeeFirstName);
		}

		String employeeLastName = (String)attributes.get("employeeLastName");

		if (employeeLastName != null) {
			setEmployeeLastName(employeeLastName);
		}

		Date employeeDob = (Date)attributes.get("employeeDob");

		if (employeeDob != null) {
			setEmployeeDob(employeeDob);
		}

		String employeeJob = (String)attributes.get("employeeJob");

		if (employeeJob != null) {
			setEmployeeJob(employeeJob);
		}

		String employeeDepartment = (String)attributes.get(
			"employeeDepartment");

		if (employeeDepartment != null) {
			setEmployeeDepartment(employeeDepartment);
		}
	}

	@Override
	public Employee cloneWithOriginalValues() {
		return wrap(model.cloneWithOriginalValues());
	}

	/**
	 * Returns the employee department of this employee.
	 *
	 * @return the employee department of this employee
	 */
	@Override
	public String getEmployeeDepartment() {
		return model.getEmployeeDepartment();
	}

	/**
	 * Returns the employee dob of this employee.
	 *
	 * @return the employee dob of this employee
	 */
	@Override
	public Date getEmployeeDob() {
		return model.getEmployeeDob();
	}

	/**
	 * Returns the employee first name of this employee.
	 *
	 * @return the employee first name of this employee
	 */
	@Override
	public String getEmployeeFirstName() {
		return model.getEmployeeFirstName();
	}

	/**
	 * Returns the employee ID of this employee.
	 *
	 * @return the employee ID of this employee
	 */
	@Override
	public long getEmployeeId() {
		return model.getEmployeeId();
	}

	/**
	 * Returns the employee job of this employee.
	 *
	 * @return the employee job of this employee
	 */
	@Override
	public String getEmployeeJob() {
		return model.getEmployeeJob();
	}

	/**
	 * Returns the employee last name of this employee.
	 *
	 * @return the employee last name of this employee
	 */
	@Override
	public String getEmployeeLastName() {
		return model.getEmployeeLastName();
	}

	/**
	 * Returns the primary key of this employee.
	 *
	 * @return the primary key of this employee
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the uuid of this employee.
	 *
	 * @return the uuid of this employee
	 */
	@Override
	public String getUuid() {
		return model.getUuid();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the employee department of this employee.
	 *
	 * @param employeeDepartment the employee department of this employee
	 */
	@Override
	public void setEmployeeDepartment(String employeeDepartment) {
		model.setEmployeeDepartment(employeeDepartment);
	}

	/**
	 * Sets the employee dob of this employee.
	 *
	 * @param employeeDob the employee dob of this employee
	 */
	@Override
	public void setEmployeeDob(Date employeeDob) {
		model.setEmployeeDob(employeeDob);
	}

	/**
	 * Sets the employee first name of this employee.
	 *
	 * @param employeeFirstName the employee first name of this employee
	 */
	@Override
	public void setEmployeeFirstName(String employeeFirstName) {
		model.setEmployeeFirstName(employeeFirstName);
	}

	/**
	 * Sets the employee ID of this employee.
	 *
	 * @param employeeId the employee ID of this employee
	 */
	@Override
	public void setEmployeeId(long employeeId) {
		model.setEmployeeId(employeeId);
	}

	/**
	 * Sets the employee job of this employee.
	 *
	 * @param employeeJob the employee job of this employee
	 */
	@Override
	public void setEmployeeJob(String employeeJob) {
		model.setEmployeeJob(employeeJob);
	}

	/**
	 * Sets the employee last name of this employee.
	 *
	 * @param employeeLastName the employee last name of this employee
	 */
	@Override
	public void setEmployeeLastName(String employeeLastName) {
		model.setEmployeeLastName(employeeLastName);
	}

	/**
	 * Sets the primary key of this employee.
	 *
	 * @param primaryKey the primary key of this employee
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the uuid of this employee.
	 *
	 * @param uuid the uuid of this employee
	 */
	@Override
	public void setUuid(String uuid) {
		model.setUuid(uuid);
	}

	@Override
	public String toXmlString() {
		return model.toXmlString();
	}

	@Override
	protected EmployeeWrapper wrap(Employee employee) {
		return new EmployeeWrapper(employee);
	}

}