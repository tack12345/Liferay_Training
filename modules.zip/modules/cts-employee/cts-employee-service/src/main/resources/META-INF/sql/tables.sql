create table cts_Employee (
	uuid_ VARCHAR(75) null,
	employeeId LONG not null primary key,
	employeeFirstName VARCHAR(75) null,
	employeeLastName VARCHAR(75) null,
	employeeDob DATE null,
	employeeJob VARCHAR(75) null,
	employeeDepartment VARCHAR(75) null
);