package com.training.custommvcaction.constants;

/**
 * @author 2264878
 */
public class CustomMVCActionCommandPortletKeys {

	public static final String CUSTOMMVCACTIONCOMMAND =
		"com_training_custommvcaction_CustomMVCActionCommandPortlet";

}