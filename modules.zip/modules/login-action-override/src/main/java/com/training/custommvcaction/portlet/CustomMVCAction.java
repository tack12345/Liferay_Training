package com.training.custommvcaction.portlet;

import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(
	    property = { 
	        "javax.portlet.name=com_liferay_login_web_portlet_LoginPortlet", 
	        "mvc.command.name=/login/login",
	        "service.ranking:Integer=100" 
	    }, 
	    service = MVCActionCommand.class
	    )


public class CustomMVCAction extends BaseMVCActionCommand {

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		
		System.out.println("You have sucessfully logged in with Admin role");
		mvcActionCommand.processAction(actionRequest, actionResponse);
		
	}
	@Reference(
	        target = "(component.name=com.liferay.login.web.internal.portlet.action.LoginMVCActionCommand)")
	    protected MVCActionCommand mvcActionCommand;
	
	

}
