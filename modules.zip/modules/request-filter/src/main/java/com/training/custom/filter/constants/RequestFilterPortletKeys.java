package com.training.custom.filter.constants;

/**
 * @author 2264878
 */
public class RequestFilterPortletKeys {

	public static final String REQUESTFILTER =
		"com_training_custom_filter_RequestFilterPortlet";

}