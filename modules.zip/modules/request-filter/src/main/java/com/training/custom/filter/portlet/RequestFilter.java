package com.training.custom.filter.portlet;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.BaseFilter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.osgi.service.component.annotations.Component;

@Component(
		property = {
		"servlet-context-name=",
		"servlet-filter-name=com_training_custom_filter_RequestFilterPortlet",
		"url-pattern=/*"
		},
		service=Filter.class
		)
public class RequestFilter extends BaseFilter {
	
	
	private final Log _log=LogFactoryUtil.getLog(RequestFilter.class);
	@Override
	protected void processFilter(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			FilterChain filterChain) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("THIS IS CUSTOM LOGS:");
		System.out.println("RequestUrl: "+httpServletRequest.getRequestURI());
		super.processFilter(httpServletRequest, httpServletResponse, filterChain);
	}
	
	
	@Override
	protected Log getLog() {
		// TODO Auto-generated method stub
		return _log;
	}

}
